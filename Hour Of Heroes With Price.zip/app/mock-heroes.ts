import { Hero } from './hero';

export var HEROES: Hero[] = [
  { 'id': 11, 'name': 'Mr. Nice', 'price': '12'},
  { 'id': 12, 'name': 'Narco', 'price': '12'},
  { 'id': 13, 'name': 'Bombasto', 'price': '12'},
  { 'id': 14, 'name': 'Celeritas', 'price': '12'},
  { 'id': 15, 'name': 'Magneta', 'price': '12'},
  { 'id': 16, 'name': 'RubberMan', 'price': '12'},
  { 'id': 17, 'name': 'Dynama', 'price': '12'},
  { 'id': 18, 'name': 'Dr IQ', 'price': '12'},
  { 'id': 19, 'name': 'Magma', 'price': '12'},
  { 'id': 20, 'name': 'Tornado', 'price': '12'}
];
