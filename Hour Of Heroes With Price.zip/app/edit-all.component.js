/**
 * Created by coryginsberg on 4/27/16.
 */
System.register(['angular2/core', 'angular2/common', './hero.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, common_1, hero_service_1;
    var EditAllComponent;
    function entryValidator(control) {
        var reg = new RegExp(control.value.match(/^[0-9]+$/));
        if (!reg.test(control.value)) {
            return { invalidEntry: true };
        }
    }
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (common_1_1) {
                common_1 = common_1_1;
            },
            function (hero_service_1_1) {
                hero_service_1 = hero_service_1_1;
            }],
        execute: function() {
            EditAllComponent = (function () {
                function EditAllComponent(_heroService, fb) {
                    this._heroService = _heroService;
                    this.myForm = fb.group({
                        'entry': ['', common_1.Validators.compose([
                                common_1.Validators.required, entryValidator])]
                    });
                    this.entry = this.myForm.controls['entry'];
                }
                EditAllComponent.prototype.getHeroes = function () {
                    var _this = this;
                    this._heroService.getHeroes().then(function (heroes) { return _this.heroes = heroes; });
                };
                EditAllComponent.prototype.ngOnInit = function () {
                    this.getHeroes();
                };
                EditAllComponent = __decorate([
                    core_1.Component({
                        selector: 'edit-all',
                        directives: [common_1.CORE_DIRECTIVES, common_1.FORM_DIRECTIVES],
                        template: "\n    <h1>{{title}}</h1>\n    <h2>Edit All Heroes</h2>\n\n    <form [ngFormModel]=\"myForm\" class=\"ui form\">\n      <table *ngFor=\"#hero of heroes\">\n          <thead>\n            <tr>\n              <th>ID</th>\n              <th>Hero Name</th>\n              <th>Price</th>\n            </tr>\n          </thead>\n        <tbody>\n          <tr>\n\n            <td id=\"id\"><label>{{hero.id}}</label></td>\n            <td id=\"name\"><input [(ngModel)]=\"hero.name\" placeholder=\"name\" /></td>\n\n            <div class=\"field\"\n              [class.error]=\"!entry.valid && entry.touched\">\n              <input id=\"entryInput\"\n                placeholder=\"myForm\"\n                [(ngModel)]=\"hero.price\"\n                [ngFormControl]=\"entry\"/>\n            </div>\n          <div *ngIf=\"!entry.valid\" class=\"ui error message\">Input is invalid.</div>\n          </tr>\n        </tbody>\n      </table>\n    </form>\n  ",
                        styleUrls: ['app/app.component.css'],
                    }), 
                    __metadata('design:paramtypes', [hero_service_1.HeroService, common_1.FormBuilder])
                ], EditAllComponent);
                return EditAllComponent;
            }());
            exports_1("EditAllComponent", EditAllComponent);
        }
    }
});
//# sourceMappingURL=edit-all.component.js.map