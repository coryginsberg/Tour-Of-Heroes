System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var HEROES;
    return {
        setters:[],
        execute: function() {
            exports_1("HEROES", HEROES = [
                { 'id': 11, 'name': 'Mr. Nice', 'price': '12' },
                { 'id': 12, 'name': 'Narco', 'price': '12' },
                { 'id': 13, 'name': 'Bombasto', 'price': '12' },
                { 'id': 14, 'name': 'Celeritas', 'price': '12' },
                { 'id': 15, 'name': 'Magneta', 'price': '12' },
                { 'id': 16, 'name': 'RubberMan', 'price': '12' },
                { 'id': 17, 'name': 'Dynama', 'price': '12' },
                { 'id': 18, 'name': 'Dr IQ', 'price': '12' },
                { 'id': 19, 'name': 'Magma', 'price': '12' },
                { 'id': 20, 'name': 'Tornado', 'price': '12' }
            ]);
        }
    }
});
//# sourceMappingURL=mock-heroes.js.map